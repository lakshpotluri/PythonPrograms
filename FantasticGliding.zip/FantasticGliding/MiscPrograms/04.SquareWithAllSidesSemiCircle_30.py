import turtle;
import math;
f=turtle.Pen();
f.shape("turtle");
f.color("blue");
for i in range(4):
    f.forward(100);
    f.left(90);

for i in range(4):
	f.right(90)
	f.circle(50,180)
