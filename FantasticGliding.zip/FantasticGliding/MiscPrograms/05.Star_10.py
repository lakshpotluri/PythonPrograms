import turtle;
f = turtle.Pen();
f.color("blue");
f.shape("turtle");
f.left(70);
for i in range(5):
    f.forward(100);
    f.right(145);

