import turtle;
j=turtle.Pen();
j.shape("turtle");
j.color("green");
j.circle(100);
j.left(90)
j.up()
j.forward(50)
j.down()
j.right(90)
j.circle(50)
j.left(90)
j.forward(100)
j.left(90)
j.circle(50,90)
j.left(90)
j.forward(100)
          
