import turtle;
f=turtle.Pen()
f.circle(50)
f.right(180)
f.circle(50)
f.left(90)
f.forward(100)
f.left(180)
f.forward(200)

