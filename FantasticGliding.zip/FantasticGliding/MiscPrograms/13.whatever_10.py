import turtle
f=turtle.Pen()
for i in range(30):
    f.circle(100,123)
    f.left(39)
for i in range(23):
    f.forward(10)
    f.left(90)
    f.forward(10)
    f.right(90)
    f.forward(10)
    f.left(90)
    f.forward(10)
    f.right(90)
    
