import  turtle
h=turtle.Pen()
h.speed(1)
h.right(90)
h.forward(50)
h.left(29)
h.forward(50)
h.left(180)
h.forward(50)
h.left(151)
h.right(29)
h.forward(50)
h.right(180)
h.forward(50)
h.right(151)
h.left(180)
h.forward(25)
h.right(151)
h.forward(3*12.5)
h.left(180)
h.forward(3*12.5)
h.left(61)
#h.right(5)
h.forward(3*12.5)
h.left(180)
h.forward(3*12.5)
h.left(180)
h.right(90)
h.forward(25)
h.right(90)
h.circle(20)
h.left(90)
h.up()
h.forward(20)
h.right(90)
h.forward(10)
h.down()
h.circle(1)
h.left(180)
h.up()
h.forward(20)
h.down()
h.circle(1)
h.up()
h.left(180)
h.forward(10)
h.right(90)
h.forward(10)
h.left(90)
h.down()
h.forward(10)
h.left(180)
h.forward(20)
h.up()
h.forward(200)


















